Color Picker
============

> A simple color picker plugin written in pure JavaScript, for modern browsers.

Has support for touch events. Touchy… touchy…

[Demo and Documentation](https://tovic.github.io/color-picker)